-- PLSQL DATATYPES
	/*
	
	1.Scalar Datatypes.
			Numeric :
					NUMBER :
							ex. NUMBER(4,2) i.e NUMBER(SCALE,PRECISION)
								i.e. 25.89 here SCALE = 4 & PRECISION = 2.
							
					PLS_INTEGER / BINARY_INTEGER :
					
				    BINARY_FLOAT / BINARY_DOUBLE :
					
			Character 
			Date and Time Interval 
			Boolean 
	2.Composite Datatypes.
	3.Reference Datatypes.
	4.Other Datatypes.
	
	*/
	
-- Assigning Values 

	DECLARE
		
			a NUMBER;
			b NUMBER := 10; --initialized in declare is legal.
			c NUMBER DEFAULT 9.8;
			pi  CONSTANT NUMBER DEFAULT 3.14; -- cannot be overriden.
		
	BEGIN
			a := 5; --initialized in BEGIN is legal.
			b := 15; -- overriden
			
			dbms_output.put_line('VALUE OF OUTER A IS : ' || a);
			dbms_output.put_line('VALUE OF OUTER B IS : ' || b);
			
			c := 10; -- DEFAULT value can be overriden.
			dbms_output.put_line('VALUE OF OUTER C IS : ' || c);
				
			dbms_output.put_line('VALUE OF OUTER PI IS : ' || pi);
	END;
	
	/*
	output :
				VALUE OF OUTER A IS : 5
				VALUE OF OUTER B IS : 15
				VALUE OF OUTER C IS : 10
				VALUE OF OUTER PI IS : 3.14

	*/
	
	-- Demo of rounding and precesion
	
		DECLARE
			a NUMBER(4,2);
		BEGIN
			a := 10.22; --legal
			dbms_output.put_line('VALUE OF A IS : ' || a);
			
			a := 10.228; --legal RoundOff output 10.29
			dbms_output.put_line('VALUE OF A IS : ' || a);

			/*
			a := 102.228 --Not legal after roundOff 102.23 but total numbers are 5 and scale of 'a' is 4. */
		END;
		
	-- Demo
	
		DECLARE
			a NUMBER(4,-2); --Adds 0 to left of decimal point.
		BEGIN
			a := 108.2; --legal
			dbms_output.put_line('VALUE OF A IS : ' || a);
			
			a := 104.228; --legal RoundOff output 10.29
			dbms_output.put_line('VALUE OF A IS : ' || a);

			/*
			a := 102.228 --Not legal after roundOff 102.23 but total numbers are 5 and scale of 'a' is 4. 
			dbms_output.put_line('VALUE OF A IS : ' || a);
			*/
		END;
		
		-- Output
		/* VALUE OF A IS : 100
			VALUE OF A IS : 100 */
			
			
	-- NUMBER Subtypes
	/*
			1.DEC/DECIMAL/NUMERIC
			2.DOUBLE PRECISION/FLOAT
			3.REAL
			4.INT/INTEGER/SMALLINT
			5.User defined Subtype.
					syntax: SUBTYPE <name> IS <base_type> [CONSTRAINT,NOT NULL]
					ex. SUBTYPE myinteger IS NUMBER(38,0) NOT NULL
	*/		
	
	
        -- Demo

				DECLARE
					cnt NUMBER := 1.8 ;
					SUBTYPE myinteger IS NUMBER(38,0) NOT NULL;
					mycnt myinteger :=1.8;
				BEGIN
					dbms_output.put_line('cnt : ' || cnt);
					dbms_output.put_line('mycnt : ' || mycnt);
				END;
	
			-- output
			/*	
			cnt : 1.8
			mycnt : 2
			*/
				
-- %TYPE
    -- Used to inherit datatype.
	
		DECLARE
			n NUMBER(5,2) NOT NULL DEFAULT 2.21;
			s n%TYPE := 10;
		--	t departments.dept_id%TYPE;  -- this can inherit data type of deptId from departments table.
		BEGIN
			dbms_output.put_line('n : ' || n);	
			dbms_output.put_line('s : ' || s);
		END;
		
		--output
		/*
			n : 2.21
			s : 10
		*/

-- Concept of precedance

		high              TO                low 
		
		Datetime and interval datatypes > BINARY_DOUBLE > BINARY_FLOAT > NUMBER > CHARACTER > OTHER buitIn Datatypes.
		
-- Casting of datatypes.

RULE : 1. Promotion of low precedance datatype to high precedance datatype is AUTOMATIC.
	   2. Demotion of high precedance datatype to low precedance datatype is MANUAL.
	   
	 DECLARE
			a NUMBER;
			b BINARY_DOUBLE;
			c NUMBER;
			d NUMBER;
	  BEGIN
			a := 10;
			b := 12.2;
			
			c := a + b; -- c got automatically promoted.
			d := a + TO_NUMBER(b);
			
			
			dbms_output.put_line('c : ' || c);
			dbms_output.put_line('d : ' || d);
			
	  END;