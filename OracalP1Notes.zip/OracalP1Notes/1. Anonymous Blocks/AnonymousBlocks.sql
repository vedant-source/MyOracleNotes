--ORACLE NOTES

-- Anonymous blocks Basic Structure.

                DECLARE                     --declaration sec (optional)
                |
                |
                
                BEGIN                       --Execution sec (Compulsory)
                |
                |
                
                Exception                    --Exception sec (optional)
                |
                |
                
                END ;
                
                
-- comments
    
--    single line comment

/*  multiple line COMMENT
	ved
	palwankar  */
	
	
-- Demo Code 


            DECLARE                     				--declaration sec (optional)
                
				counter NUMBER;
                
                
                BEGIN                       --Execution sec (Compulsory)
                
				counter := 100;
				dbms_output.put_line('VALUE OF COUNTER IS : ' || counter);
                
                
                Exception                    --Exception sec (optional)
                
                WHEN OTHERS THEN
				NULL;
                
            END ;
			
			
-- Nesting Of Blocks And Scope Of variables(i.e visibility of variables)

		-- Inner block can access variables in OUTER block but not vice-versa.
		

			 DECLARE                     --declaration sec (optional)
                
                counter NUMBER;
                
                BEGIN                       --Execution sec (Compulsory)
                
                counter := 100;
				dbms_output.put_line('VALUE OF OUTER COUNTER IS : ' || counter);
                
				
							   DECLARE                     --Inner declaration sec (optional)
								
								a NUMBER;
								
								BEGIN                       --Inner Execution sec (Compulsory)
								
								a := 10;
								dbms_output.put_line('VALUE OF a IS : ' || a);
								dbms_output.put_line('VALUE OF INNER COUNTER IS : ' || counter); -- It will print, it is in scope
								
								Exception                    --Inner Exception sec (optional)
								
								WHEN OTHERS THEN
								NULL;
								
								END ;
								
								-- dbms_output.put_line('VALUE OF a IS : ' || a); -- Out Of SCOPE 
																				-- (ERR : PLS-00201: identifier 'A' must be declared)
                Exception                    --Exception sec (optional)
                
                WHEN OTHERS THEN
				NULL;
                
                END ;
				
				
	-- Block Labels (To avoid naming conflict of variables)
		
		<<parent>>					--Label
		DECLARE                     --declaration sec (optional)
                
                counter NUMBER;
                
                BEGIN                       --Execution sec (Compulsory)
                
                counter := 1000;
                
							   DECLARE                     --Inner declaration sec (optional)
								
								counter NUMBER;
								
								BEGIN                       --Inner Execution sec (Compulsory)
								counter := 2;
								dbms_output.put_line('VALUE OF COUNTER IS : ' || counter); -- it will get confused which 'counter'
																									--to consider
								dbms_output.put_line('VALUE OF COUNTER IS : ' || parent.counter);															
								Exception                    --Inner Exception sec (optional)
								
								WHEN OTHERS THEN
								NULL;
								
								END ;
								
                Exception                    --Exception sec (optional)
                
                WHEN OTHERS THEN
				NULL;
                
                END ;
		
-- Practice Question

			<<parent>>					--Label
		DECLARE                     --declaration sec (optional)
                
                counter NUMBER;
                a NUMBER;
				
                BEGIN                       --Execution sec (Compulsory)
                
                counter := 1000;
				a := 10;
                
							   DECLARE                     --Inner declaration sec (optional)
								
								counter NUMBER;
								a NUMBER;
								
								BEGIN                       --Inner Execution sec (Compulsory)
								counter := 2;
								a := 5;
								
								dbms_output.put_line('VALUE OF COUNTER IS : ' || counter); 
								dbms_output.put_line('VALUE OF COUNTER IS : ' || parent.counter);
								dbms_output.put_line('VALUE OF a IS : ' || a); 
								dbms_output.put_line('VALUE OF a IS : ' || parent.a);
								
								Exception                    --Inner Exception sec (optional)
								
								WHEN OTHERS THEN
								NULL;
								
								END ;
								
                Exception                    --Exception sec (optional)
                
                WHEN OTHERS THEN
				NULL;
                
                END ;
				
				/*
				OUTPUT:
				VALUE OF COUNTER IS : 2
				VALUE OF COUNTER IS : 1000
				VALUE OF a IS : 5
				VALUE OF a IS : 10
				*/
